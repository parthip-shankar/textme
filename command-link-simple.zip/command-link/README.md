# Command Link (simple version)

A private chat for two people. One small Node.js server, no dependencies, no database, no build step.

## Use it at home (no internet needed)
1. Install Node.js (nodejs.org, version 18 or newer).
2. In this folder run: `node server.js`
3. First run only: type a name and password for each of the two users (8+ characters). They are saved hashed.
4. The terminal prints two addresses. Open `http://localhost:3000` on this computer. Your friend, on the **same Wi-Fi**, opens the "Same Wi-Fi" address on their phone or laptop.
5. Sign in with your own name and password.

Messages and images are saved in the `data/` folder. To reset everything, stop the server and delete `data/`.

## Use it over the internet
Host the folder on any Node host (Render, Railway, Fly.io, a VPS).
- Start command: `node server.js`
- Set these environment variables so no prompt is needed: `USER1_NAME`, `USER1_PASS`, `USER2_NAME`, `USER2_PASS`
- Mount a persistent disk and set `DATA_DIR` to it, otherwise messages are lost when the host restarts.
- Use HTTPS (the hosts above provide it). Browser notifications only work on HTTPS or localhost.

## What it does
Realtime messages, typing indicator, online / last seen, Sent / Read receipts, image sharing (tap to enlarge), delete your own messages, connection status, mobile and desktop layouts. Click the avatar once to allow notifications.

## Security
Passwords are hashed (scrypt). Login is rate limited. Sessions are signed HttpOnly cookies. Only the two users can read messages or images. Text is displayed as plain text, so no HTML injection. Only PNG/JPEG/WebP/GIF images up to 6 MB are accepted.

## Limits
Only two users, no message editing or search, and the home setup works only while the computer running the server is on.
