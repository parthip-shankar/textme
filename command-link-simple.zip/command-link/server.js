// Command Link: private chat for two people. No dependencies. Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), readline = require('readline');
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PORT = process.env.PORT || 3000;
fs.mkdirSync(path.join(DIR, 'uploads'), { recursive: true });
const CFG = path.join(DIR, 'config.json'), MSG = path.join(DIR, 'messages.json');
const scrypt = (p, salt) => crypto.scryptSync(p, salt, 32).toString('hex');

async function loadConfig() {
  if (fs.existsSync(CFG)) return JSON.parse(fs.readFileSync(CFG, 'utf8'));
  const e = process.env; let pairs;
  if (e.USER1_NAME && e.USER1_PASS && e.USER2_NAME && e.USER2_PASS) pairs = [[e.USER1_NAME, e.USER1_PASS], [e.USER2_NAME, e.USER2_PASS]];
  else {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = (q) => new Promise((r) => rl.question(q, r));
    console.log('First-time setup: choose a name and password for each of the two users.');
    pairs = [];
    for (const i of [1, 2]) pairs.push([(await ask(`User ${i} name: `)).trim(), (await ask(`User ${i} password (8+ characters): `)).trim()]);
    rl.close();
  }
  const [a, b] = pairs;
  if (!a[0] || !b[0] || a[0].length > 30 || b[0].length > 30 || a[0].toLowerCase() === b[0].toLowerCase()) throw new Error('Names must be different, 1-30 characters.');
  if (a[1].length < 8 || b[1].length < 8) throw new Error('Passwords need at least 8 characters.');
  const cfg = { secret: crypto.randomBytes(32).toString('hex'), users: pairs.map(([name, pass]) => { const salt = crypto.randomBytes(16).toString('hex'); return { name, salt, hash: scrypt(pass, salt) }; }) };
  fs.writeFileSync(CFG, JSON.stringify(cfg, null, 2), { mode: 0o600 });
  console.log('Saved. Passwords are stored hashed.');
  return cfg;
}

(async () => {
  const cfg = await loadConfig();
  const names = cfg.users.map((u) => u.name);
  const other = (n) => names.find((x) => x !== n);
  let msgs = fs.existsSync(MSG) ? JSON.parse(fs.readFileSync(MSG, 'utf8')) : [];
  let timer; const save = () => { clearTimeout(timer); timer = setTimeout(() => fs.writeFileSync(MSG, JSON.stringify(msgs)), 200); };
  const html = fs.readFileSync(path.join(__dirname, 'index.html'));
  const streams = new Map(names.map((n) => [n, new Set()])); const lastSeen = {};
  const push = (to, event, data) => { for (const n of to) for (const r of streams.get(n)) r.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`); };

  const sign = (s) => crypto.createHmac('sha256', cfg.secret).update(s).digest('base64url');
  const makeToken = (n) => { const p = Buffer.from(JSON.stringify({ n, e: Date.now() + 30 * 864e5 })).toString('base64url'); return p + '.' + sign(p); };
  const userOf = (req) => {
    const m = /(?:^|; )cl=([^;]+)/.exec(req.headers.cookie || ''); if (!m) return null;
    const [p, s] = m[1].split('.'); if (!p || !s) return null;
    const a = Buffer.from(sign(p)), b = Buffer.from(s); if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    try { const d = JSON.parse(Buffer.from(p, 'base64url')); return d.e > Date.now() && names.includes(d.n) ? d.n : null; } catch { return null; }
  };
  const fails = new Map();
  const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
  const body = (req) => new Promise((ok, no) => { let n = 0; const c = []; req.on('data', (d) => { n += d.length; if (n > 8e6) { no(new Error('big')); req.destroy(); } else c.push(d); }); req.on('end', () => { try { ok(JSON.parse(Buffer.concat(c) || '{}')); } catch { no(new Error('bad')); } }); });
  const pub = (m) => m;

  http.createServer(async (req, res) => {
    const url = req.url.split('?')[0];
    const sec = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer' };
    for (const k in sec) res.setHeader(k, sec[k]);
    try {
      if (req.method === 'GET' && url === '/') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(html); }
      if (req.method === 'POST' && url === '/api/login') {
        const ip = req.socket.remoteAddress, f = fails.get(ip) || { n: 0, t: Date.now() };
        if (Date.now() - f.t > 6e5) { f.n = 0; f.t = Date.now(); }
        if (f.n >= 10) return json(res, 429, { error: 'Too many attempts. Try again in a few minutes.' });
        const { name, password } = await body(req);
        const u = cfg.users.find((x) => x.name.toLowerCase() === String(name || '').trim().toLowerCase());
        const ok = u && typeof password === 'string' && crypto.timingSafeEqual(Buffer.from(scrypt(password, u.salt)), Buffer.from(u.hash));
        if (!ok) { f.n++; fails.set(ip, f); return json(res, 401, { error: 'Wrong name or password.' }); }
        const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
        res.setHeader('Set-Cookie', `cl=${makeToken(u.name)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${30 * 86400}${secure}`);
        return json(res, 200, { ok: true });
      }
      const me = userOf(req);
      if (!me) return json(res, 401, { error: 'Not signed in.' });
      const friend = other(me);
      if (req.method === 'POST' && url === '/api/logout') { res.setHeader('Set-Cookie', 'cl=; HttpOnly; Path=/; Max-Age=0'); return json(res, 200, { ok: true }); }
      if (req.method === 'GET' && url === '/api/me') return json(res, 200, { me, friend, online: streams.get(friend).size > 0, lastSeen: lastSeen[friend] || null, messages: msgs.filter((m) => m.from === me || m.to === me).slice(-300).map(pub) });
      if (req.method === 'GET' && url === '/api/stream') {
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
        res.write('retry: 2000\n\n');
        const set = streams.get(me); set.add(res);
        if (set.size === 1) push([friend], 'presence', { online: true });
        const ka = setInterval(() => res.write(': ping\n\n'), 20000);
        req.on('close', () => { clearInterval(ka); set.delete(res); if (!set.size) { lastSeen[me] = Date.now(); push([friend], 'presence', { online: false, lastSeen: lastSeen[me] }); } });
        return;
      }
      if (req.method === 'GET' && url.startsWith('/uploads/')) {
        const f = path.basename(url); const m = msgs.find((x) => x.image === f && (x.from === me || x.to === me) && !x.deleted);
        if (!m) { res.writeHead(404); return res.end(); }
        res.writeHead(200, { 'Content-Type': 'image/' + f.split('.').pop().replace('jpg', 'jpeg'), 'Cache-Control': 'private, max-age=86400' });
        return fs.createReadStream(path.join(DIR, 'uploads', f)).pipe(res);
      }
      if (req.method === 'POST' && url === '/api/send') {
        const b = await body(req); const text = String(b.text || '').trim().slice(0, 4000); let image = null;
        if (b.image) {
          const m = /^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(b.image));
          if (!m) return json(res, 400, { error: 'Only PNG, JPEG, WebP or GIF images are allowed.' });
          const buf = Buffer.from(m[2], 'base64'); if (buf.length > 6e6) return json(res, 400, { error: 'Image too large (6 MB max).' });
          image = crypto.randomUUID() + '.' + (m[1] === 'jpeg' ? 'jpg' : m[1]); fs.writeFileSync(path.join(DIR, 'uploads', image), buf);
        }
        if (!text && !image) return json(res, 400, { error: 'Nothing to send.' });
        const msg = { id: crypto.randomUUID(), from: me, to: friend, text, image, at: Date.now(), readAt: null, deleted: false };
        msgs.push(msg); save(); push([me, friend], 'message', msg); return json(res, 200, msg);
      }
      if (req.method === 'POST' && url === '/api/delete') {
        const { id } = await body(req); const m = msgs.find((x) => x.id === id && x.from === me);
        if (!m) return json(res, 404, { error: 'Not found.' });
        if (m.image) fs.rm(path.join(DIR, 'uploads', m.image), () => {});
        m.deleted = true; m.text = ''; m.image = null; save(); push([me, friend], 'update', m); return json(res, 200, { ok: true });
      }
      if (req.method === 'POST' && url === '/api/read') {
        const ids = []; const now = Date.now();
        for (const m of msgs) if (m.to === me && !m.readAt) { m.readAt = now; ids.push(m.id); }
        if (ids.length) { save(); push([me, friend], 'read', { ids, at: now }); }
        return json(res, 200, { ok: true });
      }
      if (req.method === 'POST' && url === '/api/typing') { push([friend], 'typing', {}); return json(res, 200, { ok: true }); }
      json(res, 404, { error: 'Not found.' });
    } catch (e) { if (!res.headersSent) json(res, 400, { error: 'Bad request.' }); }
  }).listen(PORT, '0.0.0.0', () => {
    const ips = Object.values(require('os').networkInterfaces()).flat().filter((i) => i.family === 'IPv4' && !i.internal).map((i) => i.address);
    console.log(`\nCommand Link is running.\n  This computer:  http://localhost:${PORT}`);
    ips.forEach((ip) => console.log(`  Same Wi-Fi:     http://${ip}:${PORT}   <- give this to your friend`));
  });
  process.on('SIGINT', () => { fs.writeFileSync(MSG, JSON.stringify(msgs)); process.exit(); });
})().catch((e) => { console.error('\nError: ' + e.message); process.exit(1); });
